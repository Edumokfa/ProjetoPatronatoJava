package patronato;

import java.sql.Date;
import java.util.Objects;

/**
 *
 * @author Computação
 */
public class Funcionario {
    private Integer funCod;
    private String funDesc;
    private Date funDtAdm;
    private Date funDtDemi;
    private String funPis;
    private String funCnh;
    private String funCpf;
    private String funEmail;

    public Funcionario() {
    }

    public Integer getFunCod() {
        return funCod;
    }

    public void setFunCod(Integer funCod) {
        this.funCod = funCod;
    }

    public String getFunDesc() {
        return funDesc;
    }

    public void setFunDesc(String funDesc) {
        this.funDesc = funDesc;
    }

    public Date getFunDtAdm() {
        return funDtAdm;
    }

    public void setFunDtAdm(Date funDtAdm) {
        this.funDtAdm = funDtAdm;
    }

    public Date getFunDtDemi() {
        return funDtDemi;
    }

    public void setFunDtDemi(Date funDtDemi) {
        this.funDtDemi = funDtDemi;
    }

    public String getFunPis() {
        return funPis;
    }

    public void setFunPis(String funPis) {
        this.funPis = funPis;
    }

    public String getFunCnh() {
        return funCnh;
    }

    public void setFunCnh(String funCnh) {
        this.funCnh = funCnh;
    }

    public String getFunCpf() {
        return funCpf;
    }

    public void setFunCpf(String funCpf) {
        this.funCpf = funCpf;
    }

    public String getFunEmail() {
        return funEmail;
    }

    public void setFunEmail(String funEmail) {
        this.funEmail = funEmail;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.funCod);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Funcionario other = (Funcionario) obj;
        if (!Objects.equals(this.funCod, other.funCod)) {
            return false;
        }
        return true;
    }
}