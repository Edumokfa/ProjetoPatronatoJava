package patronato;

import interfaces.interfacePrincipal;

/**
 *
 * @author Mokfa
 */
public class Patronato {

    public static void main(String[] args) {
        interfacePrincipal inte = new interfacePrincipal();
        inte.setVisible(true);
    }

}
