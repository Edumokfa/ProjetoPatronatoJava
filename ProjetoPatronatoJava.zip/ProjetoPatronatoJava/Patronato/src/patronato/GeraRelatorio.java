package patronato;

import java.util.List;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class GeraRelatorio {

    public JasperPrint gerarRelatorio(String nomeRelatorio, List<Funcionario> valores) {
        try {
            JRDataSource dataSource = new JRBeanCollectionDataSource(valores);
            return JasperFillManager.fillReport("src/patronato/" + nomeRelatorio + ".jasper", null, dataSource);
        } catch (JRException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return null;
    }
}
